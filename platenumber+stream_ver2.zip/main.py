import cv2
import streamlit as st
import numpy as np
import os
import pytesseract
import firebase_admin
from firebase_admin import credentials, db, storage, firestore
from datetime import datetime
from PIL import Image
import time
from streamlit_option_menu import option_menu
# from pages import chart

# 카메라 두개 연결 후, 장치 관리자에서 lg 카메라 사용 x 처리

pytesseract.pytesseract.tesseract_cmd = r'C:/Program Files/Tesseract-OCR/tesseract'

output_folder = 'C:/Users/seoje/PycharmProjects/platenumber+stream_ver/captured_images/'
os.makedirs(output_folder, exist_ok=True)


# Firebase 서비스 계정 JSON 파일의 경로
cred = credentials.Certificate('C:/Users/seoje/Downloads/capstone-b431a-firebase-adminsdk-aeanf-e34b58e2c5.json')
if not firebase_admin._apps:
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://capstone-b431a-default-rtdb.firebaseio.com/',  # Firebase 프로젝트 URL로 변경
        'storageBucket': 'capstone-b431a.appspot.com'
    })

db_2 = firestore.client()

pre_res = ''
pre_alcohol = -1
pre_doc_id = '_'

# 데이터 업데이트 함수 정의
def update_data():
    plate_number_dic = db.reference('plate_number').get()
    plate_number_value = plate_number_dic.get("plate_number")
    timestamp_value = plate_number_dic.get("timestamp")
    check_result_value = plate_number_dic.get("check_result")

    sensor_Alcohol_dic = db.reference('sensor_Alcohol').get()
    sensor_Alcohol_value = sensor_Alcohol_dic.get("알코올")

    return plate_number_value, timestamp_value, sensor_Alcohol_value, check_result_value

# 현재 시간, 자동차 번호, 음주 측정 수치, 대포차 표시
timestamp_text = st.empty()
plate_number_text = st.empty()
sensor_Alcohol_text = st.empty()
check_result_text = st.empty()

# 변수 초기화
plate_number_value = None
timestamp_value = None
sensor_Alcohol_value = None
check_result_value = None
led_value = None

# led 이미지
led_red = Image.open(r'C:\Users\seoje\OneDrive\Desktop\캡스톤2\images\red.png')
led_green = Image.open(r'C:\Users\seoje\OneDrive\Desktop\캡스톤2\images\green.png')

st.title("음주 운전 단속")

# 카메라 설정 및 캡처
capture1 = cv2.VideoCapture(0) # 번호판 캡쳐용 (카메라 인식 순서에 따라 달라짐 *)
capture2 = cv2.VideoCapture(1) # 민증 캡쳐용

capture_interval = 5

# Streamlit 엘리먼트 생성
stframe1 = st.empty()
stframe2 = st.empty()
data_col, led_col = st.columns(2)

data_col = st.container()
with data_col:
    text_timestamp = st.empty()
    text_plate_number = st.empty()
    text_sensor_Alcohol = st.empty()

led_col = st.container()
# 초기 LED 상태 표시
with led_col:
    led_img = st.empty()

start_time = time.time()

try:
    while True:

        ret1, frame1 = capture1.read()
        ret2, frame2 = capture2.read()
        new_plate_number, new_timestamp, new_sensor_Alcohol, new_check_result = update_data()

        if not ret1 or not ret2:
            break

        # 두 개의 프레임을 가로로 병합
        frame = np.hstack((frame1, frame2))

        # 스트림 엘리먼트에 이미지 표시
        stframe1.image(frame, channels="BGR", use_column_width=True)

        # 데이터 표시
        if (new_plate_number != plate_number_value or
                new_timestamp != timestamp_value or
                new_sensor_Alcohol != sensor_Alcohol_value):
            # 값들 업데이트
            plate_number_value = new_plate_number
            timestamp_value = new_timestamp
            sensor_Alcohol_value = new_sensor_Alcohol

            # 값들 표시 업데이트
            with data_col:
                text_timestamp.text("현재 시간 : " + str(timestamp_value))
                text_plate_number.text("자동차 번호 : " + str(plate_number_value))
                text_sensor_Alcohol.text("음주 측정 수치 : " + str(sensor_Alcohol_value))

        # LED 표시
        state_dic = db.reference('state').get()
        state_value = state_dic.get("LED")

        # 값들 표시 업데이트
        with led_col:
            if state_dic["LED"] == "red":
                led_img.image(led_red, width=200)
            elif state_dic["LED"] == "green":
                led_img.image(led_green, width=200)

        # 5초에 한번마다 if 절 들어가서 사진 촬영

        current_time = time.time()

        if current_time - start_time >= capture_interval:
            ret, frame = capture1.read()

            if ret:
                filename = f"{output_folder}{time.strftime('%Y%m%d_%H%M%S')}.jpg"
                cv2.imwrite(filename, frame)

                result = pytesseract.image_to_string(frame, lang='kor')
                result = result.replace(" ", "").replace("\n", "")  # 공백과 개행 문자 제거

                # 알콜 센서 값 갱신
                new_alcohol_dic = db.reference('sensor_Alcohol').get()
                new_alcohol = new_alcohol_dic.get("알코올")

                if pre_res != result and all(c.isdigit() or '가' <= c <= '힣' for c in result) and result != '' and len(result) == 7:
                    print(len(result))
                    print("Recognized Plate Number:", result)

                    doc_id = time.strftime('%Y-%m-%d %H:%M:%S')

                    # Firebase에 데이터 업로드 (Realtime Database)
                    realtime_db = db.reference('plate_number')  # 레퍼런스 생성
                    realtime_db.update({
                        'plate_number': result,
                        'timestamp': doc_id
                    })

                    # 알콜 센서 값 들어오면 데이터 추가할 수 있도록 가장 최신으로 생성된 파일명 저장
                    pre_doc_id = doc_id

                    # tx_dat = "num" + result[:2] + "  " + result[3:] + "        " + "\n"
                    # sp.write(tx_dat.encode()) # 시리얼 통신 시 한글 문자 제거

                    cv2.imshow("Captured Image", frame)
                    start_time += 5
                    pre_res = result
                    check_res = 'x'

                    # 민증 캡쳐를 위한 대기 후 캡처, 글자 인식 후 업로드 (사진 + 텍스트 ver)
                    time.sleep(3)
                    ret2, frame2 = capture2.read()

                    if ret2:
                        time_res = time.strftime('%Y%m%d_%H%M%S')
                        filename2 = f"{output_folder}{time_res}_idcard.jpg"
                        cv2.imwrite(filename2, frame2)

                        result2 = pytesseract.image_to_string(frame2, lang='kor')
                        print("ID : ", result2)

                        # Firebase에 주민 등록 번호 업로드 (Realtime Database)
                        realtime_db = db.reference('ID')  # 레퍼런스 생성
                        realtime_db.update({
                            'ID': result2})

                        # Firebase 스토리지 클라이언트 생성
                        storage_client = storage.bucket()

                        # 업로드할 스토리지 경로 (원하는 경로로 수정)
                        destination_blob_name = 'images/%s.jpg' % time_res

                        # 이미지 업로드
                        blob = storage_client.blob(destination_blob_name)
                        blob.upload_from_filename(filename2)

                        print(f'이미지 업로드 완료: {blob.public_url}')



                if pre_alcohol != new_alcohol and pre_res == result:
                    doc_id = time.strftime('%Y-%m-%d %H:%M:%S')

                    state_dic = db.reference('plate_number').get()
                    p_n = state_dic.get("plate_number")
                    p_t = state_dic.get("timestamp")

                    # Firebase에 데이터 업로드 (Firestore)
                    data = {
                        'plate_number': p_n,
                        'timestamp': p_t,
                        'alcohol': new_alcohol
                    }
                    db_2.collection('recognized_plates').document(doc_id).set(data)

                    pre_alcohol = new_alcohol

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    capture1.release()
    capture2.release()
    cv2.destroyAllWindows()


