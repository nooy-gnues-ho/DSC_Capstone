import numpy as np
import pandas as pd
import streamlit as st

# Create a DataFrame with the specific coordinates
marker_data = pd.DataFrame({'lat': [36.3494], 'lon': [127.302]})

# Title
st.subheader('Map')

# Display the map with markers
st.map(marker_data)