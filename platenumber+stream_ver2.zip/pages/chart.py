import streamlit as st
import firebase_admin
from firebase_admin import credentials, db
import pandas as pd
import time
import plotly.express as px
from datetime import datetime


# Firebase 인증 정보 설정
cred = credentials.Certificate(r'C:/Users/seoje/Downloads/capstone-b431a-firebase-adminsdk-aeanf-e34b58e2c5.json')

# Firebase 앱 초기화
if not firebase_admin._apps:
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://capstone-b431a-default-rtdb.firebaseio.com'
    })

# 차트 작성
# st.title("음주 운전 적발 현황")

# Streamlit 페이지 설정
st.set_page_config(page_title="알코올 센서 모니터링")

# 현재 시간 정보
current_time = datetime.now()
formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')

st.write("현재 시간 : ", formatted_time)

# 데이터 프레임 초기화
cumulative_df = pd.DataFrame(columns=['Timestamp', 'Alcohol', 'PlateNumber'])

# 그래프를 담을 공간 생성
chart = st.empty()

def plot_alcohol_sensor_data():
    global cumulative_df
    while True:
        environment_dic = db.reference('sensor_Alcohol').get()
        plate_number_dic = db.reference('plate_number').get()
        if environment_dic and plate_number_dic:
            # 새 데이터 포맷 생성
            new_data = pd.DataFrame({'Timestamp': [datetime.now()], 'Alcohol': [environment_dic['알코올']], 'PlateNumber': [plate_number_dic['plate_number']]})

            # 기존 데이터와 새 데이터 병합
            cumulative_df = pd.concat([cumulative_df, new_data], ignore_index=True)
            cumulative_df = cumulative_df.sort_values(by='Timestamp')

            # 그래프 그리기
            fig = px.line(cumulative_df, x='Timestamp', y='Alcohol', title='알코올 센서 모니터링',
                          hover_data=['PlateNumber', 'Alcohol'])
            chart.plotly_chart(fig)

        time.sleep(5)  # 5초마다 업데이트

if __name__ == "__main__":
    plot_alcohol_sensor_data()